$(document).ready(function(){
	cartClicked();
    $('.mainMenuList').click(function(e){
       $('.mainMenuList').each(function(a,b){
            $(b).css('background','');
        })
        var tempName=e.currentTarget.innerText.trim();
        $(e.currentTarget).css({'background':'aliceblue','border-radius':'15px'});
        $('.mainMenu').each(function(a,b){
            $(b).css('display','none');
        })
        $("[name='"+tempName+"']").css('display','');
        switch(tempName){
            case "Home":{
                            var mainResult=connectingDatabase("");

                        }
                        break;
        }
    });
	$('#menuMain').empty();
	menuList("Chinese Food");
	$('.cat-item').click(function(e){
		var current=e.currentTarget;
		$('.cat-item').each(function(a,b){
            $(b).css({'color':'','text-decoration':''});
        })
		$(e.currentTarget).css({'color':'red','text-decoration':'underline'});
		$('#menuMain').empty();
		var tempName=e.currentTarget.innerText.trim();
		menuList(tempName);
	})
})