function cartClicked(){
	$('.border').click(function(e){
		var current=e.currentTarget;
		if($(current).attr('check')!=1){
			$(current).attr('check',1);
			$(current).off('click');
			$(current).hover(function(){
				$(this).css('background','transparent');
			})
			current.inneText="Added To Cart";	
			$(current).css({'color':'green','border-color':'green'});
			$(current).prepend('<span class="glyphicon glyphicon-ok"></span>');
			$('.itemNumberCount')[0].innerText=Number($('.itemNumberCount')[0].innerText)+1;
		}
	})
}